"""The student written functions for the Connect-N game.
"""

from math import sqrt

# Do not change these constants!
EMPTY = '-'
DOWN = 'down'
ACROSS = 'across'
DOWN_RIGHT = 'down_right'
DOWN_LEFT = 'down_left'
MAX_BOARD_SIZE = 9


def between(value: int, min_value: int, max_value: int) -> bool:
    """Return True if and only if value is between min_value and
    max_value, inclusive.

    Precondition: min_value <= max_value

    >>> between(1, 0, 2)
    True
    >>> between(0, 2, 3)
    False
    """

    # complete the implementation of this function


# Implement the rest of the required functions here.


if __name__ == '__main__':
    
    import doctest

    # Uncomment this line to run the examples in your docstrings.
    # doctest.testmod()
