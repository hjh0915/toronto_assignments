"""Assignment 2: Palindromes"""


# Delete these two lines and write your Task 1 code here.  Don't forget to 
# run a2_simple_check.py to check parameter and return types, and style!


if __name__ == '__main__':
    pass

    # Uncomment the next two lines to run the examples in your docstrings.
    #import doctest
    #doctest.testmod()
