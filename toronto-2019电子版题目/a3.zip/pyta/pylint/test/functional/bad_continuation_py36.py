# pylint: disable=missing-docstring, unused-argument

async def upload_post(
        content: bytes,
        source: str,
        tags: dict) -> dict:
    # regression test for https://github.com/PyCQA/pylint/issues/1415
    raise NotImplementedError('Not implemented')
