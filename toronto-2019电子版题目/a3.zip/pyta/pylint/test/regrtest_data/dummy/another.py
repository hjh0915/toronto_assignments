# pylint: disable=missing-docstring

ANOTHER = 42
